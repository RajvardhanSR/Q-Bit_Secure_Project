from flask import Flask, request, jsonify
from flask_cors import CORS
from qkd_simulation import QKDSimulation
from eavesdropping_detection import EavesdroppingDetector
import traceback

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Initialize simulators
qkd_simulator = QKDSimulation()
eavesdropping_detector = EavesdroppingDetector()

@app.route('/')
def home():
    return jsonify({
        "status": "online",
        "message": "QuantumKeyLab Backend API",
        "endpoints": [
            "/simulate-qkd",
            "/detect-eavesdropping",
            "/anomaly-timeline",
            "/detect-ibm-anomalies"
        ]
    })

@app.route('/simulate-qkd', methods=['POST'])
def simulate_qkd():
    try:
        data = request.get_json()
        n = data.get('n', 100)  # Number of qubits, default 100
        
        if n < 10 or n > 1000:
            return jsonify({"error": "Number of qubits must be between 10 and 1000"}), 400
        
        results = qkd_simulator.run_simulation(n)
        return jsonify(results)
    
    except Exception as e:
        print(f"Error in simulate_qkd: {str(e)}")
        print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500

@app.route('/detect-eavesdropping', methods=['POST'])
def detect_eavesdropping():
    try:
        data = request.get_json()
        num_qubits = data.get('num_qubits', 5)
        num_bits = data.get('num_bits', 100)
        
        if num_qubits < 1 or num_qubits > 10:
            return jsonify({"error": "Number of qubits must be between 1 and 10"}), 400
        
        if num_bits < 10 or num_bits > 500:
            return jsonify({"error": "Number of bits must be between 10 and 500"}), 400
        
        results = eavesdropping_detector.detect_eavesdropping(num_qubits, num_bits)
        return jsonify(results)
    
    except Exception as e:
        print(f"Error in detect_eavesdropping: {str(e)}")
        print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500

@app.route('/anomaly-timeline', methods=['GET'])
def get_anomaly_timeline():
    try:
        results = eavesdropping_detector.get_anomaly_timeline()
        return jsonify(results)
    
    except Exception as e:
        print(f"Error in get_anomaly_timeline: {str(e)}")
        print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500

@app.route('/detect-ibm-anomalies', methods=['POST'])
def detect_ibm_anomalies():
    try:
        data = request.get_json()
        backend_name = data.get('backend_name', 'ibmq_qasm_simulator')
        api_token = data.get('api_token', None)
        
        results = eavesdropping_detector.detect_anomalies_with_ibm(backend_name, api_token)
        return jsonify(results)
    
    except Exception as e:
        print(f"Error in detect_ibm_anomalies: {str(e)}")
        print(traceback.format_exc())
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    print("Starting QuantumKeyLab Flask Backend...")
    print("Endpoints available:")
    print("  - POST /simulate-qkd")
    print("  - POST /detect-eavesdropping")
    print("  - GET  /anomaly-timeline")
    print("  - POST /detect-ibm-anomalies")
    app.run(debug=True, host='0.0.0.0', port=5001)
