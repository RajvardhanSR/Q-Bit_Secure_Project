# QuantumKeyLab Flask Backend

This is the Flask backend for the QuantumKeyLab project. It provides quantum simulation endpoints using Qiskit.

## Setup Instructions

### 1. Install Python Dependencies

```bash
cd backend
pip install -r requirements.txt
```

Or using a virtual environment (recommended):

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Run the Flask Server

```bash
python app.py
```

The server will start on `http://localhost:5001`

### 3. Configure Frontend

In your frontend `.env` file, set:

```
VITE_API_URL=http://localhost:5001
```

## API Endpoints

### POST /simulate-qkd
Runs a quantum key distribution simulation using BB84, E91, E92, and Six-State protocols.

**Request Body:**
```json
{
  "n": 100
}
```

**Response:**
```json
{
  "keys": {
    "BB84": "10101100...",
    "E91": "11001010...",
    "E92": "10110101...",
    "Six-State": "01101100..."
  },
  "entropy": {
    "BB84": 0.98,
    "E91": 0.97,
    "E92": 0.99,
    "Six-State": 0.96
  },
  "qber": 0.05,
  "execution_time": 2.3,
  "num_qubits": 100,
  "key_lengths": {
    "BB84": 48,
    "E91": 45,
    "E92": 50,
    "Six-State": 47
  }
}
```

### POST /detect-eavesdropping
Analyzes quantum communication for eavesdropping attempts.

**Request Body:**
```json
{
  "num_qubits": 5,
  "num_bits": 100
}
```

**Response:**
```json
{
  "eavesdropping_detected": true,
  "qber": 0.23,
  "confidence": 0.87,
  "eve_strategy": "intercept-resend",
  "affected_qubits": 3,
  "error_rates": [0.2, 0.4, 0.1, 0.3, 0.2],
  "timestamp": "2025-01-15T10:30:00"
}
```

### GET /anomaly-timeline
Returns historical anomaly detection data.

### POST /detect-ibm-anomalies
Simulates anomaly detection using IBM Quantum backend.

## Troubleshooting

### Port Already in Use
If port 5001 is already in use, change it in `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5002)
```

And update your frontend `.env`:
```
VITE_API_URL=http://localhost:5002
```

### Qiskit Installation Issues
If you encounter issues installing Qiskit, try:
```bash
pip install --upgrade pip
pip install qiskit qiskit-aer --use-pep517
```

## Production Deployment

For production, use a production-grade WSGI server like Gunicorn:

```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5001 app:app
```
