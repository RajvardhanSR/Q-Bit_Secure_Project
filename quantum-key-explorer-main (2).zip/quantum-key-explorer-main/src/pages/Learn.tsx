import { motion } from "framer-motion";
import { ArrowRight, Key, Atom, Eye } from "lucide-react";

const Learn = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 py-16"
      >
        <motion.h1
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-12 bg-gradient-to-r from-accent via-primary to-primary-glow bg-clip-text text-transparent"
        >
          How QKD Works
        </motion.h1>

        <div className="space-y-16 max-w-5xl">
          {/* Classical vs Quantum Cryptography */}
          <motion.section
            initial={{ x: -50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl font-bold mb-6 text-primary">Classical vs Quantum Cryptography</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <Key className="w-8 h-8 mr-3 text-muted-foreground" />
                  <h3 className="text-2xl font-semibold">Classical Cryptography</h3>
                </div>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start">
                    <span className="text-destructive mr-2">✗</span>
                    <span>Based on mathematical complexity (RSA, AES)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-destructive mr-2">✗</span>
                    <span>Vulnerable to quantum computers (Shor's algorithm)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-destructive mr-2">✗</span>
                    <span>Cannot detect eavesdropping during key exchange</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-destructive mr-2">✗</span>
                    <span>Security depends on computational difficulty</span>
                  </li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-primary/20 to-accent/20 border border-primary rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <Atom className="w-8 h-8 mr-3 text-primary animate-quantum-spin" />
                  <h3 className="text-2xl font-semibold">Quantum Cryptography</h3>
                </div>
                <ul className="space-y-3 text-foreground">
                  <li className="flex items-start">
                    <span className="text-accent mr-2">✓</span>
                    <span>Based on quantum mechanics principles</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-accent mr-2">✓</span>
                    <span>Immune to quantum computer attacks</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-accent mr-2">✓</span>
                    <span>Automatically detects any eavesdropping attempt</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-accent mr-2">✓</span>
                    <span>Information-theoretic security (unbreakable)</span>
                  </li>
                </ul>
              </div>
            </div>
          </motion.section>

          {/* Heisenberg's Uncertainty Principle */}
          <motion.section
            initial={{ x: 50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl font-bold mb-6 text-primary-glow">Heisenberg's Uncertainty Principle</h2>
            
            <div className="bg-card border border-border rounded-lg p-8">
              <p className="text-xl text-muted-foreground leading-relaxed mb-6">
                The foundation of quantum security lies in Heisenberg's Uncertainty Principle, which states that
                measuring a quantum system inevitably disturbs it.
              </p>

              <div className="bg-background/50 rounded-lg p-6 mb-6 border-l-4 border-primary">
                <p className="text-lg font-mono text-accent">
                  Δx · Δp ≥ ℏ/2
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  You cannot simultaneously know both the position and momentum of a quantum particle with arbitrary precision.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-start">
                  <Eye className="w-6 h-6 mr-3 mt-1 text-primary flex-shrink-0" />
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Detection Mechanism</h4>
                    <p className="text-muted-foreground">
                      When Eve (an eavesdropper) tries to measure photons sent between Alice and Bob, she unavoidably
                      changes their quantum state. This disturbance increases the error rate and reveals her presence.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <ArrowRight className="w-6 h-6 mr-3 mt-1 text-accent flex-shrink-0" />
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Quantum Security Guarantee</h4>
                    <p className="text-muted-foreground">
                      This means that any attempt to intercept the quantum key will be detected immediately, allowing
                      Alice and Bob to abort the communication and try again with a fresh key.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.section>

          {/* BB84 Protocol Overview */}
          <motion.section
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl font-bold mb-6 text-accent">The BB84 Protocol</h2>
            
            <div className="bg-gradient-to-br from-accent/10 to-primary/10 border border-accent/30 rounded-lg p-8">
              <p className="text-xl text-muted-foreground mb-8">
                BB84 is the first and most widely studied quantum key distribution protocol, invented by Charles Bennett
                and Gilles Brassard in 1984.
              </p>

              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-primary text-primary-foreground rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0 mr-4">
                    1
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Alice Prepares Photons</h4>
                    <p className="text-muted-foreground">
                      Alice randomly chooses bits (0 or 1) and bases (rectilinear + or diagonal ×) to encode her
                      information into photon polarization states.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-accent text-accent-foreground rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0 mr-4">
                    2
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Bob Measures</h4>
                    <p className="text-muted-foreground">
                      Bob randomly chooses measurement bases for each incoming photon. If his basis matches Alice's,
                      he gets the correct bit value.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary-glow text-primary-foreground rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0 mr-4">
                    3
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Public Comparison</h4>
                    <p className="text-muted-foreground">
                      Alice and Bob publicly compare their measurement bases (not the bits themselves) and keep only
                      the bits where their bases matched.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-secondary text-secondary-foreground rounded-full w-10 h-10 flex items-center justify-center font-bold flex-shrink-0 mr-4">
                    4
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Error Checking</h4>
                    <p className="text-muted-foreground">
                      They sacrifice some bits to check the error rate (QBER). A high error rate indicates
                      eavesdropping, and they abort the protocol.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Visual Diagram */}
          <motion.section
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-card border border-border rounded-lg p-8"
          >
            <h3 className="text-2xl font-bold mb-6 text-center">Quantum Communication Flow</h3>
            
            <div className="flex items-center justify-between gap-4">
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center mb-2 mx-auto">
                  <span className="text-2xl font-bold text-primary">A</span>
                </div>
                <p className="text-sm font-semibold">Alice</p>
                <p className="text-xs text-muted-foreground">Sender</p>
              </div>

              <div className="flex-1 relative h-1 bg-gradient-to-r from-primary via-accent to-primary-glow">
                <motion.div
                  className="absolute w-4 h-4 bg-accent rounded-full top-1/2 -translate-y-1/2"
                  animate={{ x: [0, 300, 0] }}
                  transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
                />
              </div>

              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-accent/20 border-2 border-accent flex items-center justify-center mb-2 mx-auto">
                  <span className="text-2xl font-bold text-accent">B</span>
                </div>
                <p className="text-sm font-semibold">Bob</p>
                <p className="text-xs text-muted-foreground">Receiver</p>
              </div>
            </div>

            <div className="text-center mt-6 text-muted-foreground">
              <p className="text-sm">Quantum photons travel through the quantum channel</p>
              <p className="text-xs mt-1">Any measurement attempt by Eve disturbs the quantum state</p>
            </div>
          </motion.section>
        </div>
      </motion.div>
    </div>
  );
};

export default Learn;
