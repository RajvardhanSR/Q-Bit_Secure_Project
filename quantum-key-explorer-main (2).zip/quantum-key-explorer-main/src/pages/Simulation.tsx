import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Play, AlertTriangle, CheckCircle, Loader2 } from "lucide-react";
import axios from "axios";
import SimulationResults from "@/components/SimulationResults";
import EavesdroppingResults from "@/components/EavesdroppingResults";

// ✅ Use local backend or env variable
const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:5001";

const Simulation = () => {
  const [qkdLoading, setQkdLoading] = useState(false);
  const [eveLoading, setEveLoading] = useState(false);
  const [qkdResults, setQkdResults] = useState<any>(null);
  const [eveResults, setEveResults] = useState<any>(null);

  // ✅ Axios instance with JSON headers
  const axiosInstance = axios.create({
    baseURL: API_URL,
    headers: {
      "Content-Type": "application/json",
    },
  });

  // 🔹 Run QKD Simulation
  const runQKDSimulation = async () => {
    setQkdLoading(true);
    setQkdResults(null);

    try {
      const response = await axiosInstance.post("/simulate-qkd", { n: 128 }); //set bits as you want changing n
      setQkdResults(response.data);
      toast.success("✅ QKD Simulation completed successfully!");
    } catch (error: any) {
      console.error("Error running QKD simulation:", error);
      toast.error(error.response?.data?.error || "Failed to run QKD simulation. Make sure Flask backend is running.");
    } finally {
      setQkdLoading(false);
    }
  };

  // 🔹 Detect Eavesdropping
  const detectEavesdropping = async () => {
    setEveLoading(true);
    setEveResults(null);

    try {
      const response = await axiosInstance.post("/detect-eavesdropping", {
        num_qubits: 5,
        num_bits: 100,
      });
      setEveResults(response.data);

      if (response.data.eavesdropping_detected) {
        toast.error("⚠️ Eavesdropping detected! Communication may be compromised.");
      } else {
        toast.success("✓ Channel secure - No eavesdropping detected.");
      }
    } catch (error: any) {
      console.error("Error detecting eavesdropping:", error);
      toast.error(error.response?.data?.error || "Failed to detect eavesdropping. Make sure Flask backend is running.");
    } finally {
      setEveLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 py-16"
      >
        <motion.h1
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-12 bg-gradient-to-r from-primary via-accent to-primary-glow bg-clip-text text-transparent"
        >
          Interactive Quantum Simulation
        </motion.h1>

        <div className="space-y-12 max-w-6xl mx-auto">
          {/* 🧩 QKD Simulation Section */}
          <motion.section
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <Card className="bg-card border-border p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-primary mb-2">Quantum Key Distribution (BB84)</h2>
                  <p className="text-muted-foreground">
                    Run a live quantum key distribution simulation using multiple protocols.
                  </p>
                </div>
                <Button
                  onClick={runQKDSimulation}
                  disabled={qkdLoading}
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  {qkdLoading ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Simulating...
                    </>
                  ) : (
                    <>
                      <Play className="mr-2 h-5 w-5" /> Run Simulation
                    </>
                  )}
                </Button>
              </div>

              {qkdLoading && (
                <div className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                      className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"
                    />
                    <p className="text-muted-foreground">Running quantum simulation...</p>
                  </div>
                </div>
              )}

              {qkdResults && <SimulationResults results={qkdResults} />}

              {!qkdLoading && !qkdResults && (
                <div className="text-center py-12 text-muted-foreground">
                  <p className="text-lg">Click “Run Simulation” to start the BB84 quantum key distribution protocol.</p>
                  <p className="text-sm mt-2">Backend endpoint: {API_URL}/simulate-qkd</p>
                </div>
              )}
            </Card>
          </motion.section>

          {/* 🔐 Eavesdropping Detection Section */}
          <motion.section
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            <Card className="bg-card border-border p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-accent mb-2">Eavesdropping Detection</h2>
                  <p className="text-muted-foreground">
                    Analyze quantum communication for potential security threats.
                  </p>
                </div>
                <Button
                  onClick={detectEavesdropping}
                  disabled={eveLoading}
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  {eveLoading ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Detecting...
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="mr-2 h-5 w-5" /> Detect Eavesdropping
                    </>
                  )}
                </Button>
              </div>

              {eveLoading && (
                <div className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      className="w-16 h-16 border-4 border-accent rounded-full mx-auto mb-4 flex items-center justify-center"
                    >
                      <AlertTriangle className="w-8 h-8 text-accent" />
                    </motion.div>
                    <p className="text-muted-foreground">Analyzing quantum channel...</p>
                  </div>
                </div>
              )}

              {eveResults && <EavesdroppingResults results={eveResults} />}

              {!eveLoading && !eveResults && (
                <div className="text-center py-12 text-muted-foreground">
                  <p className="text-lg">Click “Detect Eavesdropping” to analyze for potential attacks.</p>
                  <p className="text-sm mt-2">Backend endpoint: {API_URL}/detect-eavesdropping</p>
                </div>
              )}
            </Card>
          </motion.section>

          {/* ⚙️ Backend Configuration Section */}
          <Card className="bg-muted/50 border-border p-6">
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <CheckCircle className="w-5 h-5 mr-2 text-accent" />
              Backend Configuration
            </h3>
            <p className="text-sm text-muted-foreground mb-2">
              Flask backend URL: <code className="bg-background px-2 py-1 rounded">{API_URL}</code>
            </p>
            <p className="text-sm text-muted-foreground">
              Set <code className="bg-background px-2 py-1 rounded">VITE_API_URL</code> in your <code>.env</code> file to
              change the backend endpoint.
            </p>
          </Card>
        </div>
      </motion.div>
    </div>
  );
};

export default Simulation;
