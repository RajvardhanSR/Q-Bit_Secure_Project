import { motion } from "framer-motion";
import { Shield, Zap, Lock } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 py-16"
      >
        <motion.h1
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-8 bg-gradient-to-r from-primary via-primary-glow to-accent bg-clip-text text-transparent"
        >
          What is Quantum Key Distribution?
        </motion.h1>

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="space-y-8 max-w-4xl"
        >
          <p className="text-xl leading-relaxed text-muted-foreground">
            Quantum Key Distribution (QKD) is a revolutionary method of secure communication that uses the principles
            of quantum mechanics to create and distribute encryption keys between two parties.
          </p>

          <div className="grid md:grid-cols-3 gap-6 my-12">
            <motion.div
              whileHover={{ scale: 1.05, boxShadow: "var(--glow-quantum)" }}
              className="bg-card border border-border rounded-lg p-6 transition-all"
            >
              <Shield className="w-12 h-12 mb-4 text-primary" />
              <h3 className="text-2xl font-semibold mb-2">Unbreakable Security</h3>
              <p className="text-muted-foreground">
                QKD provides security guaranteed by the laws of physics, not mathematical complexity.
              </p>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05, boxShadow: "var(--glow-cyan)" }}
              className="bg-card border border-border rounded-lg p-6 transition-all"
            >
              <Zap className="w-12 h-12 mb-4 text-accent" />
              <h3 className="text-2xl font-semibold mb-2">Quantum Physics</h3>
              <p className="text-muted-foreground">
                Uses quantum properties like superposition and entanglement to detect eavesdropping.
              </p>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05, boxShadow: "var(--glow-quantum)" }}
              className="bg-card border border-border rounded-lg p-6 transition-all"
            >
              <Lock className="w-12 h-12 mb-4 text-primary-glow" />
              <h3 className="text-2xl font-semibold mb-2">Future-Proof</h3>
              <p className="text-muted-foreground">
                Protected against quantum computers that could break traditional encryption methods.
              </p>
            </motion.div>
          </div>

          <div className="bg-card border border-border rounded-lg p-8 my-8">
            <h2 className="text-3xl font-bold mb-4 text-primary">About QuantumKeyLab</h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-4">
              QuantumKeyLab is an interactive educational platform designed to make quantum cryptography accessible
              to everyone. Whether you're a student, researcher, or curious mind, our platform provides hands-on
              experience with quantum key distribution protocols.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Through live simulations powered by Qiskit, you can explore the BB84 protocol, detect eavesdropping
              attempts, and understand how quantum mechanics provides the foundation for next-generation secure
              communication.
            </p>
          </div>

          <div className="bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/30 rounded-lg p-6">
            <h3 className="text-2xl font-semibold mb-3">Why Quantum Cryptography Matters</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-start">
                <span className="text-accent mr-2">▸</span>
                <span>Traditional encryption may be vulnerable to quantum computers in the future</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">▸</span>
                <span>QKD provides information-theoretic security that cannot be broken</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">▸</span>
                <span>Any eavesdropping attempt is immediately detectable due to quantum measurement</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">▸</span>
                <span>Already being deployed for government and financial communications worldwide</span>
              </li>
            </ul>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default About;
