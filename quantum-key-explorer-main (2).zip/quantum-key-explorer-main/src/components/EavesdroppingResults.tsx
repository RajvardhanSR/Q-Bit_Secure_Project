import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { AlertTriangle, Shield, Target, Zap } from "lucide-react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

interface EavesdroppingResultsProps {
  results: any;
}

const EavesdroppingResults = ({ results }: EavesdroppingResultsProps) => {
  const chartData = {
    labels: results.error_rates?.map((_: any, i: number) => `Round ${i + 1}`) || [],
    datasets: [
      {
        label: "Error Rate",
        data: results.error_rates || [],
        borderColor: results.eavesdropping_detected
          ? "rgba(239, 68, 68, 1)"
          : "rgba(6, 182, 212, 1)",
        backgroundColor: results.eavesdropping_detected
          ? "rgba(239, 68, 68, 0.2)"
          : "rgba(6, 182, 212, 0.2)",
        borderWidth: 2,
        tension: 0.4,
        fill: true,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: "Error Rate Over Time",
        color: "rgba(203, 213, 225, 1)",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 1,
        ticks: { color: "rgba(203, 213, 225, 0.7)" },
        grid: { color: "rgba(203, 213, 225, 0.1)" },
      },
      x: {
        ticks: { color: "rgba(203, 213, 225, 0.7)" },
        grid: { color: "rgba(203, 213, 225, 0.1)" },
      },
    },
  };

  const qberPercentage = (results.qber * 100).toFixed(2);
  const confidencePercentage = (results.confidence * 100).toFixed(1);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6 mt-6"
    >
      {/* Alert Banner */}
      {results.eavesdropping_detected ? (
        <motion.div
          initial={{ scale: 0.95 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.3 }}
          className="p-6 rounded-lg border-2 border-destructive bg-destructive/10"
        >
          <div className="flex items-start">
            <motion.div
              animate={{ rotate: [0, -10, 10, -10, 0] }}
              transition={{ repeat: Infinity, duration: 2, repeatDelay: 1 }}
            >
              <AlertTriangle className="w-8 h-8 text-destructive mr-4 flex-shrink-0" />
            </motion.div>
            <div>
              <h3 className="text-xl font-bold text-destructive mb-2">⚠️ Eavesdropping Detected!</h3>
              <p className="text-muted-foreground mb-2">
                Unusual quantum noise patterns suggest potential interception attempts.
              </p>
              <p className="text-sm text-destructive">
                Strategy: <span className="font-semibold">{results.eve_strategy}</span>
              </p>
            </div>
          </div>
        </motion.div>
      ) : (
        <motion.div
          initial={{ scale: 0.95 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.3 }}
          className="p-6 rounded-lg border-2 border-accent bg-accent/10"
        >
          <div className="flex items-center">
            <Shield className="w-8 h-8 text-accent mr-4" />
            <div>
              <h3 className="text-xl font-bold text-accent mb-1">✓ Channel Secure</h3>
              <p className="text-muted-foreground">No eavesdropping detected. Communication is safe.</p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Stats Grid */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-4 bg-background/50">
          <div className="flex items-center mb-2">
            <Target className="w-5 h-5 mr-2 text-destructive" />
            <span className="text-sm text-muted-foreground">QBER</span>
          </div>
          <p className="text-2xl font-bold">{qberPercentage}%</p>
          <p className="text-xs text-muted-foreground mt-1">Quantum Bit Error Rate</p>
        </Card>

        <Card className="p-4 bg-background/50">
          <div className="flex items-center mb-2">
            <Zap className="w-5 h-5 mr-2 text-accent" />
            <span className="text-sm text-muted-foreground">Confidence</span>
          </div>
          <p className="text-2xl font-bold">{confidencePercentage}%</p>
          <p className="text-xs text-muted-foreground mt-1">Detection Confidence</p>
        </Card>

        <Card className="p-4 bg-background/50">
          <div className="flex items-center mb-2">
            <AlertTriangle className="w-5 h-5 mr-2 text-primary" />
            <span className="text-sm text-muted-foreground">Affected Qubits</span>
          </div>
          <p className="text-2xl font-bold">{results.affected_qubits}</p>
          <p className="text-xs text-muted-foreground mt-1">Potentially Compromised</p>
        </Card>
      </div>

      {/* Error Rate Chart */}
      <Card className="p-6 bg-background/50">
        <h3 className="text-xl font-bold mb-4">Error Rate Analysis</h3>
        <Line data={chartData} options={chartOptions} />
        <div className="mt-4 p-3 bg-muted/30 rounded">
          <p className="text-sm text-muted-foreground">
            Error rates above 11% typically indicate eavesdropping attempts. Current QBER: {qberPercentage}%
          </p>
        </div>
      </Card>

      {/* Detection Details */}
      {results.eavesdropping_detected && (
        <Card className="p-6 bg-destructive/5 border-destructive/30">
          <h3 className="text-xl font-bold mb-4 text-destructive">Threat Analysis</h3>
          <div className="space-y-3">
            <div className="flex items-start">
              <div className="w-2 h-2 bg-destructive rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <p className="font-semibold">Attack Strategy</p>
                <p className="text-sm text-muted-foreground">{results.eve_strategy}</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="w-2 h-2 bg-destructive rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <p className="font-semibold">Recommendation</p>
                <p className="text-sm text-muted-foreground">
                  Abort current key exchange and retry with a fresh quantum channel. Consider implementing error
                  correction and privacy amplification protocols.
                </p>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Quantum State Visualization */}
      <div className="relative h-24 bg-gradient-to-r from-transparent via-destructive/20 to-transparent rounded-lg overflow-hidden border border-destructive/30">
        {results.eavesdropping_detected && (
          <motion.div
            className="absolute top-1/2 -translate-y-1/2 w-6 h-6 bg-destructive rounded-full"
            animate={{ x: [-50, 800] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            style={{ boxShadow: "0 0 20px rgba(239, 68, 68, 0.8)" }}
          />
        )}
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-sm text-muted-foreground">
            {results.eavesdropping_detected ? "⚠️ Compromised Channel" : "✓ Secure Quantum Channel"}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default EavesdroppingResults;
