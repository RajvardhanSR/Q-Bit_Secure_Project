import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { CheckCircle, Key, Clock, Hash } from "lucide-react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface SimulationResultsProps {
  results: any;
}

const SimulationResults = ({ results }: SimulationResultsProps) => {
  const chartData = {
    labels: Object.keys(results.entropy || {}),
    datasets: [
      {
        label: "Entropy",
        data: Object.values(results.entropy || {}),
        backgroundColor: "rgba(139, 92, 246, 0.6)",
        borderColor: "rgba(139, 92, 246, 1)",
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: "Key Entropy by Protocol",
        color: "rgba(203, 213, 225, 1)",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 1,
        ticks: { color: "rgba(203, 213, 225, 0.7)" },
        grid: { color: "rgba(203, 213, 225, 0.1)" },
      },
      x: {
        ticks: { color: "rgba(203, 213, 225, 0.7)" },
        grid: { color: "rgba(203, 213, 225, 0.1)" },
      },
    },
  };

  const qberPercentage = (results.qber * 100).toFixed(2);
  const isSecure = results.qber < 0.11;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6 mt-6"
    >
      {/* Status Banner */}
      <div
        className={`p-4 rounded-lg border-2 ${
          isSecure
            ? "bg-accent/10 border-accent"
            : "bg-destructive/10 border-destructive"
        }`}
      >
        <div className="flex items-center">
          <CheckCircle
            className={`w-6 h-6 mr-3 ${
              isSecure ? "text-accent" : "text-destructive"
            }`}
          />
          <div>
            <h3 className="text-lg font-bold">
              {isSecure ? "✓ Secure Communication" : "⚠️ High Error Rate Detected"}
            </h3>
            <p className="text-sm text-muted-foreground">
              QBER: {qberPercentage}% {isSecure ? "(Below threshold)" : "(Above 11% threshold)"}
            </p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-4 bg-background/50">
          <div className="flex items-center mb-2">
            <Clock className="w-5 h-5 mr-2 text-primary" />
            <span className="text-sm text-muted-foreground">Execution Time</span>
          </div>
          <p className="text-2xl font-bold">{results.execution_time?.toFixed(2)}s</p>
        </Card>

        <Card className="p-4 bg-background/50">
          <div className="flex items-center mb-2">
            <Hash className="w-5 h-5 mr-2 text-accent" />
            <span className="text-sm text-muted-foreground">Total Qubits</span>
          </div>
          <p className="text-2xl font-bold">{results.num_qubits}</p>
        </Card>

        <Card className="p-4 bg-background/50">
          <div className="flex items-center mb-2">
            <Key className="w-5 h-5 mr-2 text-primary-glow" />
            <span className="text-sm text-muted-foreground">BB84 Key Length</span>
          </div>
          <p className="text-2xl font-bold">{results.key_lengths?.BB84 || 0} bits</p>
        </Card>
      </div>

      {/* Entropy Chart */}
      <Card className="p-6 bg-background/50">
        <h3 className="text-xl font-bold mb-4">Entropy Analysis</h3>
        <Bar data={chartData} options={chartOptions} />
      </Card>

      {/* Generated Keys */}
      <Card className="p-6 bg-background/50">
        <h3 className="text-xl font-bold mb-4">Generated Keys</h3>
        <div className="space-y-3">
          {Object.entries(results.keys || {}).map(([protocol, key]: [string, any]) => (
            <div key={protocol} className="bg-muted/30 p-3 rounded">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-primary">{protocol}</span>
                <span className="text-xs text-muted-foreground">{String(key).length} bits</span>
              </div>
              <code className="text-xs text-accent break-all font-mono">
                {String(key).substring(0, 80)}
                {String(key).length > 80 && "..."}
              </code>
            </div>
          ))}
        </div>
      </Card>

      {/* Photon Animation */}
      <div className="relative h-20 bg-gradient-to-r from-transparent via-primary/20 to-transparent rounded-lg overflow-hidden">
        <motion.div
          className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-accent rounded-full"
          animate={{ x: [-50, 800] }}
          transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
          style={{ boxShadow: "0 0 20px rgba(6, 182, 212, 0.8)" }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-sm text-muted-foreground">Quantum Photon Transmission</p>
        </div>
      </div>
    </motion.div>
  );
};

export default SimulationResults;
